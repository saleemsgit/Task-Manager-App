export interface Task {
    id?: string;
    title: string;
    description: string;
    status: string;
    // Add other properties as per your Task object
  }
  